export class Visitor {
    title:string;
    name:string;
    isMarried:boolean;
    spouseName:string;
}
