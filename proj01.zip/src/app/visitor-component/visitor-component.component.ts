import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visitor-component',
  templateUrl: './visitor-component.component.html',
  styleUrls: ['./visitor-component.component.css']
})
export class VisitorComponentComponent implements OnInit {

  subTitle:string;

  constructor() { 
    this.subTitle="Visitor Page - to demostrate structural directives";
  }

  ngOnInit() {
  }

}
