import { Injectable } from '@angular/core';
import { Visitor } from '../models/visitor';

@Injectable({
  providedIn: 'root'
})
export class VisitorService {

  private visitor:Visitor;
  constructor() { 
    //this.visitor=new Visitor();
  }

  getVisitor(){
    if(!this.visitor){
      this.visitor=new Visitor();
    }
    return this.visitor;
  }
}
