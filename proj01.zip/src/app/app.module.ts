import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { WelcomeComponentComponent } from './welcome-component/welcome-component.component';
import { VisitorComponentComponent } from './visitor-component/visitor-component.component';
import { VisitorFormComponentComponent } from './visitor-form-component/visitor-form-component.component';
import { VisitorDetailsComponentComponent } from './visitor-details-component/visitor-details-component.component';
import { PipesDemoComponent } from './pipes-demo/pipes-demo.component';
import { ToWordsPipe } from './to-words.pipe';
import { TodayDirective } from './today.directive';

@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponentComponent,
    VisitorComponentComponent,
    VisitorFormComponentComponent,
    VisitorDetailsComponentComponent,
    PipesDemoComponent,
    ToWordsPipe,
    TodayDirective
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
