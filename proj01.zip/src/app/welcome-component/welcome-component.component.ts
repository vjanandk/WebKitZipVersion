import { Component } from '@angular/core';

@Component({
  selector: 'app-welcome-component',
  templateUrl: './welcome-component.component.html',
  styleUrls: ['./welcome-component.component.css']
})
export class WelcomeComponentComponent  {

  subTitle:string;

  userName:string;

  constructor() { 
    this.subTitle="A Simple Welcome Component";
    this.userName="Somebody";
  }
}
