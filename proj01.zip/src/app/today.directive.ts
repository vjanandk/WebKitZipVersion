import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appToday]'
})
export class TodayDirective {

  constructor(private ele:ElementRef) { 
    let domEle=this.ele.nativeElement;

    let d = new Date();

    let h3Ele = document.createElement("h3");
    h3Ele.textContent=d.toDateString();
    h3Ele.style.textAlign="right";

    domEle.append(h3Ele);
  }
}
