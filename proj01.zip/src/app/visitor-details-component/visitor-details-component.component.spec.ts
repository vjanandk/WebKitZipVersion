import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VisitorDetailsComponentComponent } from './visitor-details-component.component';

describe('VisitorDetailsComponentComponent', () => {
  let component: VisitorDetailsComponentComponent;
  let fixture: ComponentFixture<VisitorDetailsComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VisitorDetailsComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VisitorDetailsComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
