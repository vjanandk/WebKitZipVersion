import { Component, OnInit } from '@angular/core';
import { Visitor } from '../models/visitor';
import { VisitorService } from '../services/visitor.service';

@Component({
  selector: 'app-visitor-details-component',
  templateUrl: './visitor-details-component.component.html',
  styleUrls: ['./visitor-details-component.component.css']
})
export class VisitorDetailsComponentComponent implements OnInit {

  visitor:Visitor;
  constructor(private vs:VisitorService) { }

  ngOnInit() {
    this.visitor=this.vs.getVisitor();
  }

}
