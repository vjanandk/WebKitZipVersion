import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VisitorFormComponentComponent } from './visitor-form-component.component';

describe('VisitorFormComponentComponent', () => {
  let component: VisitorFormComponentComponent;
  let fixture: ComponentFixture<VisitorFormComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VisitorFormComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VisitorFormComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
