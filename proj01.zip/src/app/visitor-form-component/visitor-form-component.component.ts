import { Component, OnInit } from '@angular/core';
import { VisitorService } from '../services/visitor.service';
import { Visitor } from '../models/visitor';

@Component({
  selector: 'app-visitor-form-component',
  templateUrl: './visitor-form-component.component.html',
  styleUrls: ['./visitor-form-component.component.css']
})
export class VisitorFormComponentComponent implements OnInit {

  titles:string[];
  visitor:Visitor;

  constructor(private vs : VisitorService) {
    this.titles=["Mr","Mrs","Miss","Dr","Prof"];
   }

  ngOnInit() {
    this.visitor=this.vs.getVisitor();
  }

}
