import { TodayDirective } from './today.directive';

describe('TodayDirective', () => {
  it('should create an instance', () => {
    const directive = new TodayDirective();
    expect(directive).toBeTruthy();
  });
});
