import { Component, OnInit } from '@angular/core';
import { NumberSeriesService } from '../services/number-series.service';

@Component({
  selector: 'app-number-series',
  templateUrl: './number-series.component.html',
  styleUrls: ['./number-series.component.css']
})
export class NumberSeriesComponent implements OnInit {

  lb: number = 1;
  ub: number = 25;
  completed: boolean = true;
  nums: number[];
  errMsg: string;

  isEven: boolean = false;
  isSquared: boolean = false;

  constructor(private ns: NumberSeriesService) { }

  ngOnInit() {
  }

  startSeries() {
    let observable = null;

    if (this.isEven && this.isSquared)
      observable = this.ns.generateEvenSquaredSeries(this.lb, this.ub);
    else if (this.isEven)
      observable = this.ns.generateEvenSeries(this.lb, this.ub);
    else if (this.isSquared)
      observable = this.ns.generateSquaredSeries(this.lb, this.ub);
    else
      observable = this.ns.generateSeries(this.lb, this.ub);

    this.completed = false;
    this.nums = [];

    observable.subscribe(
      (n) => { this.nums.push(n); },
      (errMsg) => { this.errMsg = errMsg; },
      () => { this.completed = true; }
    );
  }
}
