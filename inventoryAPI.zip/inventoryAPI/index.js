let express = require('express');
let bp = require('body-parser');
let cors = require('cors');
let fs = require('fs');

const port = 5454;
const dataFileName = "inv.json";

let invData = null;

fs.readFile(dataFileName,(err,data)=>{
    if(err){
        console.log(err);
    }else{
        invData=JSON.parse(data);
    }
});

let saveDataAndRespond = (resp) =>{
    fs.writeFile(dataFileName,JSON.stringify(invData),(err)=>{
        if(err){
            console.log(err);
            resp.status(500); //internal server error
        }else{
            resp.status(200); //ok
        }
        resp.end();
    });
}

let parseToItem = (req) =>{
    return {
        itemId:req.body.itemId,
        name:req.body.name,
        description:req.body.description,
        packageDate:req.body.packageDate,
        price:req.body.price
    };
}

let invApp = express();

invApp.use(cors());
invApp.use(bp.urlencoded({extended:true}));
invApp.use(bp.json());

invApp.get('',(req,resp)=>{
    resp.send("Inventory API Server Responding..!");
})

invApp.get('/items',(req,resp)=>{
    if(invData){
        resp.send(invData.inv);
    }else{
        resp.status(404);
        resp.end();
    }
});

invApp.get('/items/:id',(req,resp)=>{
    let item=null;

    let id = req.params.id;

    if(invData){
        item = invData.inv.find((itm)=>itm.itemId==id);        
    }

    if(!item){
        resp.status(404);
        resp.end();
    }else{
        resp.send(item);
    }
});

invApp.delete('/items/:id',(req,resp)=>{
    let index=-1;

    let id = req.params.id;

    if(invData){
        index = invData.inv.findIndex((itm)=>itm.itemId==id);        
        if(index>-1){
            invData.inv.splice(index,1);
        }
    }

    if(index==-1){
        resp.status(404);
        resp.end();
    }else{
        saveDataAndRespond(resp);
    }
});

invApp.put('/items',(req,resp)=>{
    let index=-1;

    let item = parseToItem(req);

    if(invData){
        index = invData.inv.findIndex((itm)=>itm.itemId==item.itemId);        
        if(index>-1){
            invData.inv[index]=item;
        }
    }

    if(index==-1){
        resp.status(404);
        resp.end();
    }else{
        saveDataAndRespond(resp);
    }
});

invApp.post('/items',(req,resp)=>{

    let item = parseToItem(req);

    if(invData){
        invData.inv.push(item);
        saveDataAndRespond(resp);
    }
});

invApp.listen(port,()=>{
    console.log(`Inv Server running at ${port}....`)
})