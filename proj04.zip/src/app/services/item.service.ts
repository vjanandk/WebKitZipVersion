import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Item } from '../model/item';

@Injectable({
  providedIn: 'root'
})
export class ItemService {

  private apiUrl: string;

  constructor(private http: HttpClient) {
    this.apiUrl = 'http://localhost:5454/items';
  }

  get():Observable<Item[]>{
    return this.http.get<Item[]>(this.apiUrl);
  }

  getById(id:number):Observable<Item>{
    return this.http.get<Item>(`${this.apiUrl}/${id}`);
  }

  add(item:Item):Observable<void>{
    return this.http.post<void>(this.apiUrl,item);
  }

  save(item:Item):Observable<void>{
    return this.http.put<void>(this.apiUrl,item);
  }

  deleteById(id:number):Observable<void>{
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
