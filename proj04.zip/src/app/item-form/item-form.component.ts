import { Component, OnInit } from '@angular/core';
import { Item } from '../model/item';
import { ActivatedRoute, Router } from '@angular/router';
import { ItemService } from '../services/item.service';
import { FormControl,FormGroup, Validators, FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-item-form',
  templateUrl: './item-form.component.html',
  styleUrls: ['./item-form.component.css']
})
export class ItemFormComponent implements OnInit {

  itemGroup: FormGroup;
  isNew: boolean = true;

  constructor(private activatedRoute: ActivatedRoute,
    private itmSrv: ItemService, private router: Router,
    private fb : FormBuilder) {

      /*this.itemGroup=new FormGroup({
        itemId:new FormControl(0,[Validators.required]),
        name:new FormControl('',[Validators.required,Validators.minLength(4)]),
        description:new FormControl('',[]),
        price:new FormControl(0,[Validators.required]),
        packageDate:new FormControl(new Date().toISOString().substr(0,10),[Validators.required])
      });*/

      this.itemGroup = fb.group({
        itemId:[0,[Validators.required]],
        name:['',[Validators.required,Validators.minLength(4)]],
        description:['',[]],
        price:[0,[Validators.required]],
        packageDate:[new Date().toISOString().substr(0,10),[Validators.required]]        
      });
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(
      (params) => {
        if (params.id) {
          this.isNew = false;
          this.itmSrv.getById(params.id).subscribe(
            (data) => { 
              this.isNew=false;
              this.itemGroup.controls.itemId.setValue(data.itemId);
              this.itemGroup.controls.name.setValue(data.name);
              this.itemGroup.controls.price.setValue(data.price);
              this.itemGroup.controls.packageDate.setValue(new Date(data.packageDate).toISOString().substr(0,10));
            }
          );
        } else {
          this.isNew = true;       
        }
      }
    );
  }

  get c(){
    return this.itemGroup.controls;
  }

  save(item:Item) {
    if (this.isNew) {
      this.itmSrv.add(item).subscribe(
        () => {
          this.router.navigateByUrl('/inv');
        }
      );
    } else {
      this.itmSrv.save(item).subscribe(
        () => {
          this.router.navigateByUrl('/inv');
        }
      );
    }
  }
}
