export class Item {
    itemId:number;
    name:string;
    description:string;
    packageDate:Date;
    price:number;
}
