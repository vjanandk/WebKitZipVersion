import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Item } from '../model/item';
import { ActivatedRoute } from '@angular/router';
import { ItemService } from '../services/item.service';

@Component({
  selector: 'app-item-grid-cell',
  templateUrl: './item-grid-cell.component.html',
  styleUrls: ['./item-grid-cell.component.css']
})
export class ItemGridCellComponent implements OnInit {

  @Input()
  item:Item;

  @Output()
  delete:EventEmitter<void>;
  
  constructor(private actRt : ActivatedRoute,private itmSrv:ItemService) { 
    this.delete=new EventEmitter<void>();
  }

  ngOnInit() {
    this.actRt.params.subscribe(
      (params) =>{
        let itemId=params.id;
        if(itemId){
          this.itmSrv.getById(itemId).subscribe(
            (data)=>{
              console.log(data);
              this.item=data;
            }
          );
        }
      }
    );
  }

  fireDelete(){
    this.delete.emit();
  }
}
