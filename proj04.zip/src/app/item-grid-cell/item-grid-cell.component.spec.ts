import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemGridCellComponent } from './item-grid-cell.component';

describe('ItemGridCellComponent', () => {
  let component: ItemGridCellComponent;
  let fixture: ComponentFixture<ItemGridCellComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ItemGridCellComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemGridCellComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
