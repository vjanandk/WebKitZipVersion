"use strict";

if(true){
    var x=89;
    let y=78;
    z=34;
    console.log(x);
    console.log(y);
    console.log(z);
}

console.log(x);
//console.log(y); will generate error
console.log(z);