import {Box} from'./module1.js';

let b = new Box();
console.log(b.print());