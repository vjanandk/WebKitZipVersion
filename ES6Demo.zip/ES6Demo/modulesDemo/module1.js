export class Box{
    print(){
        return "Hah! Am a box";
    }
}