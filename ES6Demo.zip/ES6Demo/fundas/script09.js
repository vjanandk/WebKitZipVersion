//assigning a functio9n to a object

f1 = function(){
        console.log("I am called");
    }

f1(); //we can call it this way.        