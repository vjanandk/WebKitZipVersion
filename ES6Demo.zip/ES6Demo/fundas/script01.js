//we want to print a single line of string.
console.log("Hello World! Welcoem To Javascript [ES6]");