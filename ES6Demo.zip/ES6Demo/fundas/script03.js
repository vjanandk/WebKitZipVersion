fnm = "Vamsy";
lnm = "Kiran";

console.log(fnm+" "+lnm);

//string opertions
console.log(fnm.length);
console.log(fnm.substr(2,3));
console.log(fnm.substring(2,3));
console.log(fnm.charAt(3));
console.log(fnm.indexOf('a'));
console.log(fnm.indexOf('A'));
console.log(fnm.toUpperCase());
console.log(fnm.toLowerCase());

