arr1 = [];
arr2 = new Array();

arr3 = ["Rahul","Vamsy","Uma","Latha","Srinu"];

console.log(arr3);
console.log(arr3.length);

arr3.sort();
console.log(arr3);

arr1.push("Ant");
arr1.push("Elephant");
arr1.push("Tiger");
arr1.push("Zebra");
console.log(arr1);

arr1.pop();
console.log(arr1);

arr3.splice(2,2);
console.log(arr3);