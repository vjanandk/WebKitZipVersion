name = "VAMSY";

for(i=0;i<name.length;i++){
    console.log(name.substring(0,i+1));
}

