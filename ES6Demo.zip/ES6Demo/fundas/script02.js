x = 90;
y = 25;

//arithemtic oprations
console.log(x+y);
console.log(x-y);
console.log(x*y);
console.log(x/y);
console.log(x%y);

//logical operations
console.log(x===y);
console.log(x==y);
console.log(x<y);
console.log(x>y);
console.log(x<=y);
console.log(x>=y);
console.log(x!=y);