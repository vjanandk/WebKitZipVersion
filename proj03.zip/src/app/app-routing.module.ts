import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ItemFormComponent } from './item-form/item-form.component';
import { ItemsComponent } from './items/items.component';
import { ItemsListComponent } from './items-list/items-list.component';
import { ItemGridComponent } from './item-grid/item-grid.component';
import { ItemGridCellComponent } from './item-grid-cell/item-grid-cell.component';

const routes: Routes = [
  { path: '', component: DashboardComponent,pathMatch:'full' },
  { path: 'details/:id', component: ItemGridCellComponent },
  { path: 'add', component: ItemFormComponent },
  { path: 'edit/:id', component: ItemFormComponent },
  {
    path: 'inv', component: ItemsComponent,
    children: [
      { path: '', redirectTo:'list',pathMatch:'full' },
      { path: 'list', component: ItemsListComponent },
      { path: 'grid', component: ItemGridComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
