import { Component, OnInit } from '@angular/core';
import { Item } from '../model/item';
import { ActivatedRoute, Router } from '@angular/router';
import { ItemService } from '../services/item.service';

@Component({
  selector: 'app-item-form',
  templateUrl: './item-form.component.html',
  styleUrls: ['./item-form.component.css']
})
export class ItemFormComponent implements OnInit {

  item: Item;
  isNew: boolean = true;
  pkDtStr:string;

  constructor(private activatedRoute: ActivatedRoute,
    private itmSrv: ItemService, private router: Router) {
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(
      (params) => {
        if (params.id) {
          this.isNew = false;
          this.itmSrv.getById(params.id).subscribe(
            (data) => { 
              this.item = data; 
              this.pkDtStr=this.item.packageDate.toISOString().substr(0,10);
            }
          );
        } else {
          this.isNew = true;
          this.item = new Item();
          this.pkDtStr=new Date().toISOString().substr(0,10);
        }
      }
    );
  }

  updatePkDt(){
    this.item.packageDate=new Date(this.pkDtStr);
  }
  save() {
    if (this.isNew) {
      this.itmSrv.add(this.item).subscribe(
        () => {
          this.router.navigateByUrl('/inv');
        }
      );
    } else {
      this.itmSrv.save(this.item).subscribe(
        () => {
          this.router.navigateByUrl('/inv');
        }
      );
    }
  }
}
