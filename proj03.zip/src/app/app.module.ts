import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ItemsComponent } from './items/items.component';
import { ItemsListComponent } from './items-list/items-list.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ItemGridComponent } from './item-grid/item-grid.component';
import { ItemFormComponent } from './item-form/item-form.component';
import { ItemGridCellComponent } from './item-grid-cell/item-grid-cell.component';

@NgModule({
  declarations: [
    AppComponent,
    ItemsComponent,
    ItemsListComponent,
    DashboardComponent,
    ItemGridComponent,
    ItemFormComponent,
    ItemGridCellComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
