import { Component, OnInit } from '@angular/core';
import { Item } from '../model/item';
import { ItemService } from '../services/item.service';

@Component({
  selector: 'app-item-grid',
  templateUrl: './item-grid.component.html',
  styleUrls: ['./item-grid.component.css']
})
export class ItemGridComponent implements OnInit {

  items: Item[];
  errMsg: string;

  constructor(private itemSrv: ItemService) { }

  ngOnInit() {
    this.loadData();
  }

  loadData(){
    this.itemSrv.get().subscribe(
      (data) => { this.items = data; this.errMsg = ""; },
      (err) => { this.errMsg = err; this.items = null; }
    );
  }

  delete(id:number){
    if(confirm(`Are you sure of deleting item#${id}`)){
      this.itemSrv.deleteById(id).subscribe(
        ()=>{
         this.loadData(); 
        }
      );
    }
  }
}
