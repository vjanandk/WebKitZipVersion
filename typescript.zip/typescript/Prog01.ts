
var message = "Hello World! This is typescript!";
console.log(message);