var GreetService = /** @class */ (function () {
    function GreetService() {
        this.greetNote = "Good Day";
    }
    GreetService.prototype.greet = function (userName) {
        return this.greetNote + "! " + userName;
    };
    return GreetService;
}());
var gs = new GreetService();
console.log(gs.greet("Venky"));
