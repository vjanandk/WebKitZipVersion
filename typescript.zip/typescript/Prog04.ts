interface Person {
    firstName : string;
    lastName : string;

    earns() : number;
}

var emp1 : Person ={
    firstName:"Vamsy",
    lastName:"Aripaka",
    earns:()=>789000
};

