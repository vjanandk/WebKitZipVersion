//Rest Parameters
function sum() {
    var nums = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        nums[_i] = arguments[_i];
    }
    var s = 0;
    for (var _a = 0, nums_1 = nums; _a < nums_1.length; _a++) {
        var n = nums_1[_a];
        s += n;
    }
    return s;
}
console.log(sum());
console.log(sum(34));
console.log(sum(34, 67));
console.log(sum(45, 66, 77, 88));
